# examples/08_stress_test_async.py

"""
Async stress test with:
- High‑volume async logging
- Rotation
- Progress bar
- Throughput metrics
"""

# ----------------------------------------------------------------------------------------------------------
# Make ROOT_DIR a known path when executing via CLI from (active) ROOT_DIR
# ----------------------------------------------------------------------------------------------------------
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
# ----------------------------------------------------------------------------------------------------------

import asyncio
import time
from pathlib import Path

from LogSmith import AsyncSmartLogger, a_stdout
from LogSmith import RotationLogic, When
from LogSmith import LogRecordDetails, OptionalRecordFields

from project_definitions import ROOT_DIR


async def main():
    levels = AsyncSmartLogger.levels()

    await a_stdout("\nAsync Stress Test demo\n======================")

    # --------------------------------------------------------------
    # Prepare log directory
    # --------------------------------------------------------------
    await a_stdout("\nPreparing log directory...")

    log_dir = Path(ROOT_DIR) / "Logs" / "examples" / "stress_test_async"
    if log_dir.exists():
        for f in log_dir.iterdir():
            if f.is_file():
                f.unlink()

    await a_stdout("Old stress-test files removed.")

    # --------------------------------------------------------------
    # Create logger
    # --------------------------------------------------------------
    await a_stdout("\nCreating async logger 'stress.async'...")

    logger = AsyncSmartLogger("stress_async", level=levels["TRACE"])

    # --------------------------------------------------------------
    # Rotating file handler
    # --------------------------------------------------------------
    await a_stdout("\nAdding rotating file handler...")

    details = LogRecordDetails(
        datefmt="%Y-%m-%d %H:%M:%S",
        separator="|",
        optional_record_fields=OptionalRecordFields(
            process_id=True,
            thread_id=True,
        ),
        message_parts_order=[
            "process_id",
            "thread_id",
            "level",
        ],
    )

    rotation = RotationLogic(
        when = When.SECOND,
        interval = 2,
        maxBytes = 250_000,
        backupCount = 200,
    )

    logger.add_file(
        log_dir=str(log_dir),
        logfile_name="stress_test_async.log",
        level=levels["TRACE"],
        rotation_logic=rotation,
        log_record_details=details,
    )

    await a_stdout("Async stress-test logger ready.")

    # --------------------------------------------------------------
    # Stress test parameters
    # --------------------------------------------------------------
    # TASK_COUNT = 16
    # ITERATIONS = 2000
    TASK_COUNT = 32
    ITERATIONS = 5000
    TOTAL = TASK_COUNT * ITERATIONS

    # Shared progress counter
    progress = {"count": 0}
    lock = asyncio.Lock()

    # --------------------------------------------------------------
    # Worker coroutine
    # --------------------------------------------------------------
    async def worker(worker_id: int):
        for i in range(ITERATIONS):
            await logger.a_info(f"[worker {worker_id}] message {i}")

            # update progress counter
            async with lock:
                progress["count"] += 1

            if i % 50 == 0:
                await asyncio.sleep(0.02)

    # --------------------------------------------------------------
    # Progress monitor
    # --------------------------------------------------------------
    async def monitor():
        bar_width = 40
        start_time = time.time()

        while True:
            await asyncio.sleep(0.2)

            # Read both counters
            produced = logger.messages_enqueued
            processed = AsyncSmartLogger.messages_processed()
            backlog = produced - processed

            # Progress is based on processed messages
            pct = processed / TOTAL
            filled = int(pct * bar_width)
            bar = "█" * filled + "-" * (bar_width - filled)

            elapsed = time.time() - start_time
            rate = processed / elapsed if elapsed > 0 else 0

            # ETA based on remaining processed work
            remaining = TOTAL - processed
            eta = remaining / rate if rate > 0 else 0

            # Display both progress and backlog
            await a_stdout(
                f"\r[{bar}] {pct * 100:5.1f}%  "
                f"done={processed}/{TOTAL}  "
                f"produced={produced}  "
                f"backlog={backlog}  "
                f"{rate:7.1f} msg/s  "
                f"ETA {eta:5.1f}s",
                end="",
            )

            if processed >= TOTAL:
                break   # pragma: no cover

        await a_stdout()  # newline after finishing

    # --------------------------------------------------------------
    # Run workers + monitor
    # --------------------------------------------------------------
    await a_stdout(f"\nStarting async stress test with {TASK_COUNT} tasks...\n")

    logger.enable_profiling(True)

    start = time.time()

    # create worker instances
    tasks = [asyncio.create_task(worker(t)) for t in range(TASK_COUNT)]

    # create monitor for workers progress
    monitor_task = asyncio.create_task(monitor())

    await asyncio.gather(*tasks)    # DO      WORKLOAD
    await monitor_task              # Monitor WORKLOAD

    # force logger queue to empty
    await logger.flush()

    end = time.time()

    profiling_details = logger.get_profiling_details()
    await a_stdout(profiling_details)
    logger.enable_profiling(False)

    await a_stdout(f"\nStress test completed in {end - start:.2f} seconds\n")


if __name__ == "__main__":
    asyncio.run(main())
