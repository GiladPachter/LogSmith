# LogSmith/rotation.py

import errno
import os
import time
import logging
from logging.handlers import BaseRotatingHandler
from datetime import datetime, timedelta
from typing import Optional, IO, List

from LogSmith.rotation_base import BaseTimedSizedRotatingFileHandler


try:
    import fcntl  # type: ignore[attr-defined]
    _HAS_FCNTL = True   # pragma: no cover
except ImportError:  # Windows
    fcntl = None
    _HAS_FCNTL = False

try:
    import msvcrt  # type: ignore[attr-defined]
    _HAS_MSVCRT = True  # pragma: no cover
except ImportError:
    msvcrt = None
    _HAS_MSVCRT = False


from .rotation_base import (
    When,
    RotationTimestamp,
    ExpirationRule,
    ExpirationScale,
    LargeLogEntryBehavior,
)


class ConcurrentTimedSizedRotatingFileHandler (BaseTimedSizedRotatingFileHandler):
    """
    ConcurrentTimedSizedRotatingFileHandler

    - Extends BaseRotatingHandler
    - Supports:
        * size-based rotation (max_bytes)
        * time-based rotation (When + interval + Timestamp)
        * concurrent, cross-process safe rotation using OS-level locks
        * atomic renames
        * backup file management

    Filename scheme:
        base.log
        base.log.1
        base.log.2
        ...
    """

    def __init__(
        self,
        filename: str,
        *,
        when:            Optional[When] = None,
        interval:        int = 1,
        timestamp:       Optional[RotationTimestamp] = None,
        max_bytes:       int = 0,
        backup_count:    int = 7,
        expiration_rule: ExpirationRule | None = None,
        encoding: Optional[str] = "utf-8",
        large_entry_behavior: LargeLogEntryBehavior | None = None,
        append_filename_pid: bool = False,
        append_filename_timestamp: bool = False,
    ):
        os.makedirs(os.path.dirname(filename) or ".", exist_ok=True)

        # BaseRotatingHandler -> FileHandler
        BaseRotatingHandler.__init__(self, filename, mode="a", encoding=encoding)

        # Tell PyCharm the truth: stream can be None
        self.stream: Optional[IO[str]] = self.stream

        super().__init__(
            filename,
            when = when,
            interval = interval,
            timestamp = timestamp,
            max_bytes = max_bytes,
            backup_count = backup_count,
            expiration_rule = expiration_rule,
            encoding = encoding,
            large_entry_behavior = large_entry_behavior,
            append_filename_pid = append_filename_pid,
            append_filename_timestamp = append_filename_timestamp,
        )

        self.large_entry_behavior = (
            large_entry_behavior or LargeLogEntryBehavior.ExceedMaxBytesIfFileIsEmpty
        )

        # lock file for cross-process safety
        self.__lock_file = None
        self.__lock_file_path = self.baseFilename + ".lock"

        # time-based rollover scheduling
        self.__rollover_at: Optional[float] = None
        if self.when is not None:
            self.__rollover_at = self.__compute_initial_rollover()

            # noinspection PyBroadException
            try:
                if os.path.exists(self.baseFilename):
                    file_modify_time = os.path.getmtime(self.baseFilename)

                    # If the file is older than the last scheduled rollover moment,
                    # force rollover immediately.
                    if file_modify_time < (self.__rollover_at - self.__rollover_interval_seconds()):
                        # Force rollover on first emit
                        self.__rollover_at = 0
            except Exception:   # pragma: no cover
                pass    # pragma: no cover

    def handleError(self, record):
        # Silence internal logging errors
        pass

    def __rollover_interval_seconds(self) -> float:
        if self.when == When.SECOND:
            return self.interval
        if self.when == When.MINUTE:
            return self.interval * 60
        if self.when == When.HOUR:
            return self.interval * 3600 # pragma: no cover
        if self.when == When.EVERYDAY:
            return 24 * 3600
        # weekly
        return 7 * 24 * 3600

    # ------------------------------------------------------------------
    # LOCKING
    # ------------------------------------------------------------------
    def __open_lock_file(self) -> None:
        if self.__lock_file is None:
            self.__lock_file = open(self.__lock_file_path, "a+b")

    def __acquire_lock(self) -> None:
        self.__open_lock_file()
        f = self.__lock_file

        if _HAS_FCNTL:  # pragma: no cover
            while True:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                    break   # pragma: no cover
                except OSError as e:
                    if e.errno != errno.EINTR:
                        raise
        elif _HAS_MSVCRT:
            # lock 1 byte; enough to serialize access
            msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
        else:
            # no-op fallback (not ideal, but keeps API usable)
            pass    # pragma: no cover

    def __release_lock(self) -> None:
        if self.__lock_file is None:
            return  # pragma: no cover
        f = self.__lock_file

        if _HAS_FCNTL:  # pragma: no cover
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        elif _HAS_MSVCRT:   # pragma: no cover
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:   # pragma: no cover
            pass

    # ------------------------------------------------------------------
    # TIME-BASED ROLLOVER CALCULATION
    # ------------------------------------------------------------------
    def __compute_initial_rollover(self) -> float:
        now = time.time()
        return self.__compute_next_rollover(now)

    def __compute_next_rollover(self, current: float) -> float:
        """
        Compute the next rollover time after 'current' (epoch seconds),
        based on When + interval + Timestamp.
        """
        if self.when is None:   # pragma: no cover
            return float("inf")

        # simple periodic rotation
        if self.when in (When.SECOND, When.MINUTE, When.HOUR):
            if self.when == When.SECOND:
                delta = self.interval
            elif self.when == When.MINUTE:
                delta = self.interval * 60
            else:  # HOUR   -   # pragma: no cover
                delta = self.interval * 3600
            return current + delta

        # daily / weekly rotation at a specific time-of-day
        ts = self.timestamp or RotationTimestamp(hour=0, minute=0, second=0)

        now_dt = datetime.fromtimestamp(current)
        target = now_dt.replace(
            hour=ts.hour,
            minute=ts.minute,
            second=ts.second,
            microsecond=0,
        )

        if self.when == When.EVERYDAY:
            if target <= now_dt:
                target = target + timedelta(days=1)
            return target.timestamp()

        # weekday-based: Monday=0 ... Sunday=6
        weekday_map = {
            When.MONDAY: 0,
            When.TUESDAY: 1,
            When.WEDNESDAY: 2,
            When.THURSDAY: 3,
            When.FRIDAY: 4,
            When.SATURDAY: 5,
            When.SUNDAY: 6,
        }
        target_weekday = weekday_map[self.when]
        days_ahead = (target_weekday - now_dt.weekday()) % 7
        if days_ahead == 0 and target <= now_dt:
            days_ahead = 7  # pragma: no cover
        target = target + timedelta(days=days_ahead)
        return target.timestamp()

    # ------------------------------------------------------------------
    # ROLLOVER DECISION
    # ------------------------------------------------------------------
    def __shouldRollover(self, record: logging.LogRecord) -> bool:
        """
        Decide if rollover should occur (size and/or time).
        """
        if self.stream is None: # pragma: no cover
            self.stream = self._open()

        # size-based
        if self.max_bytes > 0:
            msg = f"{self.format(record)}\n"
            self.stream.seek(0, os.SEEK_END)
            current_size = self.stream.tell()
            projected = current_size + len(msg.encode(self.encoding or "utf-8"))
            if projected >= self.max_bytes:
                return True

        # time-based
        if self.__rollover_at is not None:
            now = time.time()
            if now >= self.__rollover_at:
                return True

        return False

    # ------------------------------------------------------------------
    # EMIT WITH CONCURRENCY
    # ------------------------------------------------------------------
    def __handle_large_entry(self, formatted: str) -> bool:
        """
        Apply LargeLogEntryBehavior.
        Returns True if the entry was handled and emit() should return early.
        """
        behavior = self.large_entry_behavior
        max_bytes = self.max_bytes
        if not max_bytes:
            return False  # size limit disabled

        entry_size = len(formatted)
        if entry_size <= max_bytes:
            return False  # normal path

        # Determine if file is empty
        # noinspection PyBroadException
        try:
            file_empty = (self.stream is None or self.stream.tell() == 0)
        except Exception:   # pragma: no cover
            file_empty = False  # pragma: no cover

        if behavior is LargeLogEntryBehavior.ExceedMaxBytesIfFileIsEmpty:
            if file_empty:
                # write first, then rotate
                self.stream.write(formatted)
                self.stream.flush()
                self.__doRollover()
                self.__apply_expiration_policy()
                return True
            else:
                # rotate first, then write
                self.__doRollover()
                self.__apply_expiration_policy()
                self.stream.write(formatted)
                self.stream.flush()
                return True

        if behavior is LargeLogEntryBehavior.RotateFirst:
            self.__doRollover()
            self.__apply_expiration_policy()
            self.stream.write(formatted)
            self.stream.flush()
            return True

        if behavior is LargeLogEntryBehavior.DumpSilently:
            return True  # drop entry

        if behavior is LargeLogEntryBehavior.Crash:
            raise ValueError(
                f"Log entry of size {entry_size} exceeds maxBytes={max_bytes}"
            )

        return False    # pragma: no cover

    def emit(self, record: logging.LogRecord) -> None:
        """
        Emit a record with concurrency-safe rollover.
        """
        try:
            self.__acquire_lock()

            if not self.filter(record):
                return  # pragma: no cover

            formatted = self.format(record) + self.terminator

            # Handle oversized entries according to LargeLogEntryBehavior
            if self.__handle_large_entry(formatted):
                return  # pragma: no cover

            # Normal rollover path
            if self.__shouldRollover(record):
                self.__doRollover()
                self.__apply_expiration_policy()

            # Write normally
            msg = formatted
            self.stream.write(msg)
            self.stream.flush()

        finally:
            self.__release_lock()

    # ------------------------------------------------------------------
    # ROLLOVER IMPLEMENTATION
    # ------------------------------------------------------------------
    def __rotation_suffix(self) -> str:
        parts = []
        if self.append_filename_pid:
            parts.append(str(os.getpid()))
        if self.append_filename_timestamp:
            parts.append(datetime.now().strftime("%Y%m%d_%H%M%S"))
        return ".".join(parts)

    def __doRollover(self) -> None:
        """
        Perform rollover:
            - close current file
            - rotate backups
            - reopen base file
            - compute next rollover time
        """
        if self.stream:
            self.stream.close()
            self.stream = None  # type: ignore[assignment]

        # rotate backups
        if self.backup_count > 0:
            for i in range(self.backup_count - 1, 0, -1):

                # sfn = f"{self.baseFilename}.{i}"
                # dfn = f"{self.baseFilename}.{i + 1}"
                suffix = self.__rotation_suffix()
                if suffix:
                    sfn = f"{self.baseFilename}.{suffix}.{i}"
                    dfn = f"{self.baseFilename}.{suffix}.{i + 1}"
                else:
                    sfn = f"{self.baseFilename}.{i}"
                    dfn = f"{self.baseFilename}.{i + 1}"

                if os.path.exists(sfn):
                    if os.path.exists(dfn):
                        os.remove(dfn)
                    try:
                        orig_mtime = os.path.getmtime(sfn)
                        os.replace(sfn, dfn)
                        os.utime(dfn, (orig_mtime, orig_mtime))
                    except FileNotFoundError:   # pragma: no cover
                        pass

            # dfn = f"{self.baseFilename}.1"
            suffix = self.__rotation_suffix()
            if suffix:
                dfn = f"{self.baseFilename}.{suffix}.1"
            else:
                dfn = f"{self.baseFilename}.1"

            if os.path.exists(dfn):
                os.remove(dfn)
            if os.path.exists(self.baseFilename):
                orig_mtime = os.path.getmtime(self.baseFilename)
                try:
                    os.replace(self.baseFilename, dfn)
                    os.utime(dfn, (orig_mtime, orig_mtime))
                except PermissionError: # pragma: no cover
                    # Another process still has app.log open; skip rotation in this process.
                    # We just reopen the base file below and keep logging.
                    pass

        # reopen base file
        self.stream = self._open()

        # compute next rollover time
        if self.when is not None:
            now = time.time()
            self.__rollover_at = self.__compute_next_rollover(now)
        else:
            self.__rollover_at = None

    def __apply_expiration_policy(self):
        rule = self.expiration_rule
        if rule is None:
            return  # pragma: no cover

        now = datetime.now()

        # Compute cutoff time
        if rule.scale == ExpirationScale.Seconds:
            cutoff = now - timedelta(seconds=rule.interval)
        elif rule.scale == ExpirationScale.Minutes:
            cutoff = now - timedelta(minutes=rule.interval)
        elif rule.scale == ExpirationScale.Hours:
            cutoff = now - timedelta(hours=rule.interval)
        elif rule.scale == ExpirationScale.Days:
            cutoff = now - timedelta(days=rule.interval)
        elif rule.scale == ExpirationScale.MonthDay:
            # Delete files from previous calendar days
            cutoff = now.replace(hour=0, minute=0, second=0, microsecond=0)
        else:
            return  # pragma: no cover

        # Delete rotated files older than cutoff
        for path in self.__list_rotated_files():
            if datetime.fromtimestamp(os.path.getmtime(path)) < cutoff:
                try:
                    os.remove(path)
                except OSError:
                    pass    # pragma: no cover

    def __list_rotated_files(self) -> List[str]:
        base = self.baseFilename
        dir_name = os.path.dirname(base)
        prefix = os.path.basename(base)

        return [
            os.path.join(dir_name, f)
            for f in os.listdir(dir_name)
            if f.startswith(prefix) and not f.endswith(".lock")
        ]
