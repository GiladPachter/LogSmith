# examples/10_removing_handlers_from_loggers.py

# ----------------------------------------------------------------------------------------------------------
# Make ROOT_DIR a known path when executing via CLI from (active) ROOT_DIR
# ----------------------------------------------------------------------------------------------------------
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
# ----------------------------------------------------------------------------------------------------------

import os
import shutil
from pathlib import Path

from project_definitions import ROOT_DIR

from LogSmith import SmartLogger

# ----------------------------------------------------------------------------------------------------------
# 1. Initialization
# ----------------------------------------------------------------------------------------------------------
levels = SmartLogger.levels()

# ------------------------------------------------------------
# Setup: two loggers, each with console + file handler
# ------------------------------------------------------------

logger_a = SmartLogger("A", level=levels["INFO"])
logger_b = SmartLogger("B", level=levels["INFO"])

logger_a.add_console()
logger_b.add_console()

log_dir = (Path(ROOT_DIR) / "logs" / "examples" / "removing_handlers_demo").resolve()

if os.path.exists(log_dir):
    shutil.rmtree(log_dir)

logger_a.add_file(log_dir = str(log_dir), logfile_name = "A.log")
logger_b.add_file(log_dir = str(log_dir), logfile_name = "B.log")

# ------------------------------------------------------------
# Step 1: both loggers write 3 INFO entries
# ------------------------------------------------------------

for i in range(1, 4):
    logger_a.info(f"[A] before removal #{i}")
    logger_b.info(f"[B] before removal #{i}")

# ------------------------------------------------------------
# Step 2: remove handlers
# ------------------------------------------------------------

logger_a.remove_file_handler(log_dir=str(log_dir), logfile_name="A.log")
logger_b.remove_console()

# ------------------------------------------------------------
# Step 3: both loggers write 3 more INFO entries
# ------------------------------------------------------------

for i in range(1, 4):
    logger_a.info(f"[A] after removal #{i}")
    logger_b.info(f"[B] after removal #{i}")

# ------------------------------------------------------------
# Step 4: print file contents, indented
# ------------------------------------------------------------

def print_file(label: str, path: Path):
    logger_a.stdout(f"\n=== {label} ({path}) ===")
    if not path.exists():
        logger_a.stdout("    <file missing>")
        return

    raw = path.read_bytes()
    decoded = raw.decode("utf-8")

    # Print lines
    for line in decoded.splitlines():
        logger_a.stdout("    " + line)

    logger_a.stdout("\n    NOTE:")
    if label.startswith("Logger A"):
        logger_a.stdout("    - Logger A's file is missing the *after removal* lines")
    else:
        logger_a.stdout("    - Logger B's file contains all lines (console was removed instead)")

print_file("Logger A file", Path(log_dir) / "A.log")
print_file("Logger B file", Path(log_dir) / "B.log")
