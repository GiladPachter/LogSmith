# examples/05_hierarchy_async_demo.py

"""
Demonstrates AsyncSmartLogger hierarchy behavior:
- Parent → child → grandchild
- NOTSET inheritance
- Changing parent level affects descendants
"""
import logging
# ----------------------------------------------------------------------------------------------------------
# Make ROOT_DIR a known path when executing via CLI from (active) ROOT_DIR
# ----------------------------------------------------------------------------------------------------------
import sys
from pathlib import Path

from LogSmith.levels import TRACE

sys.path.append(str(Path(__file__).resolve().parents[1]))
# ----------------------------------------------------------------------------------------------------------

import asyncio

from LogSmith import AsyncSmartLogger
from LogSmith import LogRecordDetails, OptionalRecordFields


async def main():
    print("\nAsync hierarchy demo\n====================", flush = True)

    # ------------------------------------------------------------------------------------------------------
    # 1. Levels (AsyncSmartLogger does not require global init)
    # ------------------------------------------------------------------------------------------------------
    levels = AsyncSmartLogger.levels()

    # ------------------------------------------------------------------------------------------------------
    # 2. Explain hierarchy rules
    # ------------------------------------------------------------------------------------------------------
    print("\nHierarchy rules:", flush = True)

    print(
        "  - Logger names define hierarchy via dot notation\n"
        "      parent\n"
        "      parent.child\n"
        "      parent.child.grandchild\n\n"
        "  - Level inheritance:\n"
        "      • If a logger has its own level → use it\n"
        "      • If level is NOTSET → inherit from parent\n"
        "      • If parent is NOTSET → inherit from grandparent\n"
        "      • Ultimately falls back to root logger level\n",
        flush = True
    )

    # ------------------------------------------------------------------------------------------------------
    # 3. Create loggers
    # ------------------------------------------------------------------------------------------------------
    print("\nCreating async loggers...", flush = True)

    parent     = AsyncSmartLogger("myapp",           level=levels["DEBUG"])
    child      = AsyncSmartLogger("myapp.api",       level=levels["NOTSET"])
    grandchild = AsyncSmartLogger("myapp.api.users", level=levels["NOTSET"])

    # All loggers share the same formatting
    details = LogRecordDetails(
        datefmt="%Y-%m-%d %H:%M:%S.%2f",
        separator="•",
        optional_record_fields=OptionalRecordFields(
            logger_name=True,   # hierarchy demo requires this
        ),
        message_parts_order=[
            "level",
            "logger_name",
        ],
        color_all_log_record_fields=True,
    )

    parent.add_console(level=levels["TRACE"], log_record_details=details)
    child.add_console(level=levels["TRACE"], log_record_details=details)
    grandchild.add_console(level=levels["TRACE"], log_record_details=details)

    # ------------------------------------------------------------------------------------------------------
    # Helper: exercise all loggers
    # ------------------------------------------------------------------------------------------------------
    async def exercise():
        padding = 36 * ' '

        await parent.a_debug("parent DEBUG")
        await parent.a_raw(logging.DEBUG, padding + "parent RAW DEBUG")
        await parent.a_info("parent INFO")
        await parent.a_raw(logging.INFO, padding + "parent RAW INFO")

        await child.a_debug("child DEBUG")
        await parent.a_raw(logging.DEBUG, padding + "child RAW DEBUG")
        await child.a_info("child INFO")
        await parent.a_raw(logging.INFO, padding + "child RAW INFO")

        await grandchild.a_trace("grandchild TRACE")
        await parent.a_raw(TRACE, padding + "grandchild RAW TRACE")
        await grandchild.a_debug("grandchild DEBUG")
        await parent.a_raw(logging.DEBUG, padding + "grandchild RAW DEBUG")
        await grandchild.a_warning("grandchild WARNING")
        await parent.a_raw(logging.WARNING, padding + "grandchild RAW WARNING")

        await parent.flush()
        # await child.flush()
        # await grandchild.flush()

    # ------------------------------------------------------------------------------------------------------
    # 4. Demonstrate inheritance
    # ------------------------------------------------------------------------------------------------------
    await parent.a_stdout("\nInitial behavior (parent = DEBUG, children = NOTSET → inherit DEBUG):")
    await exercise()

    # ------------------------------------------------------------------------------------------------------
    # 5. Change parent level → children inherit new level
    # ------------------------------------------------------------------------------------------------------
    await parent.a_stdout("\nChanging parent level to INFO...")

    parent.level = levels["INFO"]
    await exercise()

    # ------------------------------------------------------------------------------------------------------
    # 6. Change parent level again
    # ------------------------------------------------------------------------------------------------------
    await parent.a_stdout("\nChanging parent level to TRACE...")

    parent.level = levels["TRACE"]
    await exercise()

    # ------------------------------------------------------------------------------------------------------
    # 7. Change parent level to WARNING
    # ------------------------------------------------------------------------------------------------------
    await parent.a_stdout("\nChanging parent level to WARNING...")

    parent.level = levels["WARNING"]
    await exercise()

    await parent.a_stdout("\nAsync hierarchy demo complete.\n")

    # Ensure all logs are flushed before exit
    await parent.flush()
    await child.flush()
    await grandchild.flush()


if __name__ == "__main__":
    asyncio.run(main())