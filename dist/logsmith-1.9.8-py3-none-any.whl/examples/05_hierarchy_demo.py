# examples/05_hierarchy_demo.py

"""
Demonstrates SmartLogger hierarchy behavior:
- Parent → child → grandchild
- NOTSET inheritance
- Changing parent level affects descendants
"""
import logging
# ----------------------------------------------------------------------------------------------------------
# Make ROOT_DIR a known path when executing via CLI from (active) ROOT_DIR
# ----------------------------------------------------------------------------------------------------------
import sys
from pathlib import Path

from LogSmith.levels import TRACE

sys.path.append(str(Path(__file__).resolve().parents[1]))
# ----------------------------------------------------------------------------------------------------------

from LogSmith import SmartLogger
from LogSmith import LogRecordDetails, OptionalRecordFields


# ----------------------------------------------------------------------------------------------------------
# 1. Initialization
# ----------------------------------------------------------------------------------------------------------
levels = SmartLogger.levels()

print("\nHierarchy demo\n==============", flush = True)

# ----------------------------------------------------------------------------------------------------------
# 2. Explain hierarchy rules
# ----------------------------------------------------------------------------------------------------------
print("\nHierarchy rules:", flush = True)

print(
    "  - Logger names define hierarchy via dot notation\n"
    "      parent\n"
    "      parent.child\n"
    "      parent.child.grandchild\n\n"
    "  - Level inheritance:\n"
    "      • If a logger has its own level → use it\n"
    "      • If level is NOTSET → inherit from parent\n"
    "      • If parent is NOTSET → inherit from grandparent\n"
    "      • Ultimately falls back to root logger level\n",
    flush = True,
)

# ----------------------------------------------------------------------------------------------------------
# 3. Create loggers
# ----------------------------------------------------------------------------------------------------------
print("\nCreating loggers...", flush = True)

parent     = SmartLogger("myapp",           level=levels["DEBUG"])
child      = SmartLogger("myapp.api",       level=levels["NOTSET"])
grandchild = SmartLogger("myapp.api.users", level=levels["NOTSET"])

# All loggers share the same formatting
details = LogRecordDetails(
    datefmt="%Y-%m-%d %H:%M:%S.%2f",
    separator="•",
    optional_record_fields=OptionalRecordFields(
        logger_name=True,   # hierarchy demo requires this
    ),
    message_parts_order=[
        "level",
        "logger_name",
    ],
    color_all_log_record_fields=True,
)

parent.add_console(level=levels["TRACE"], log_record_details=details)
child.add_console(level=levels["TRACE"], log_record_details=details)
grandchild.add_console(level=levels["TRACE"], log_record_details=details)

# ----------------------------------------------------------------------------------------------------------
# Helper: exercise all loggers
# ----------------------------------------------------------------------------------------------------------
def exercise():
    padding = 36 * ' '

    parent.debug("parent DEBUG")
    parent.raw(logging.DEBUG, padding + "parent RAW DEBUG")
    parent.info("parent INFO")
    parent.raw(logging.INFO, padding + "parent RAW INFO")

    child.debug("child DEBUG")
    parent.raw(logging.DEBUG, padding + "child RAW DEBUG")
    child.info("child INFO")
    parent.raw(logging.INFO, padding + "child RAW INFO")

    grandchild.trace("grandchild TRACE")
    parent.raw(TRACE, padding + "grandchild RAW TRACE")
    grandchild.debug("grandchild DEBUG")
    parent.raw(logging.DEBUG, padding + "grandchild RAW DEBUG")
    grandchild.warning("grandchild WARNING")
    parent.raw(logging.WARNING, padding + "grandchild RAW WARNING")

# ----------------------------------------------------------------------------------------------------------
# 4. Demonstrate inheritance
# ----------------------------------------------------------------------------------------------------------
parent.stdout("\nInitial behavior (parent = DEBUG, children = NOTSET → inherit DEBUG):")
exercise()

# ----------------------------------------------------------------------------------------------------------
# 5. Change parent level → children inherit new level
# ----------------------------------------------------------------------------------------------------------
parent.stdout("\nChanging parent level to INFO...")

parent.level = levels["INFO"]
exercise()

# ----------------------------------------------------------------------------------------------------------
# 6. Change parent level again
# ----------------------------------------------------------------------------------------------------------
parent.stdout("\nChanging parent level to TRACE...")

parent.level = levels["TRACE"]
exercise()

# ----------------------------------------------------------------------------------------------------------
# 7. Change parent level to WARNING
# ----------------------------------------------------------------------------------------------------------
parent.stdout("\nChanging parent level to WARNING...")

parent.level = levels["WARNING"]
exercise()

parent.stdout("\nHierarchy demo complete.\n")
